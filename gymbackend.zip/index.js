import express from "express";
import * as url from "url";
import * as path from "path";
import bodyParser from "body-parser";
import env from "dotenv";
import Admin from "./router/Admin.js";
import session from "express-session";

const app = express();

var dirname = url.fileURLToPath(new URL("./", import.meta.url));

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

env.config();
app.use(session({ secret: "Gym Management Project" }));

app.use(express.static(path.join(dirname, "public")));

app.use("/admin", Admin);

app.listen(process.env.PORT);
console.log("server created successfully on http://localhost:3010");
