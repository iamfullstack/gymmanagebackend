import mongoose from "mongoose";
const Country = mongoose.Schema({
    country_name:
    {
        type: String,
        required:[true, "Country is required"],
        trim:true,
    },
    
})

const CountrySchema = mongoose.model("temp_country", Country, "Country_Details");
export default CountrySchema;
