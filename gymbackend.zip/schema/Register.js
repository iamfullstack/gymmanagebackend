import mongoose from "mongoose";
const Register = mongoose.Schema({
    first_name:
    {
        type: String,
        required:[true, "First Name is required"],
        trim:true,
    },
    last_name:
    {
        type: String,
        required:[true, "Last Name is required"],
        trim:true,
    },
    mobile:
    {
        type: String,
        required:[true, "Mobile Number is required"],
        maxlength:10,
        trim:true,
    },
    email:
    {
        type: String,
        required:[true, "Email Id is required"],
        lowercase:true,
        trim:true,
    },
    city:
    {
        type: String,
        required:[true, "City is required"],
    },
    password:
    {
        type: String,
        required:[true, "Password is required"],
    }
})

const RegisterSchema = mongoose.model("temp_reg", Register, "User_Registration_Details");
export default RegisterSchema;
